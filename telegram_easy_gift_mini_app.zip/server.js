const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(bodyParser.json());

const gifts = [
  { name: "Парфум", chance: 0.1 },
  { name: "Плюшевий ведмедик", chance: 0.3 },
  { name: "Казковий змій", chance: 0.2 },
  { name: "Капсула-сюрприз", chance: 0.4 }
];

function pickGift() {
  const rand = Math.random();
  let acc = 0;
  for (const gift of gifts) {
    acc += gift.chance;
    if (rand <= acc) return gift.name;
  }
  return gifts[gifts.length - 1].name;
}

app.post('/buy', async (req, res) => {
  const userId = req.body.user_id;
  // Тут потрібно перевіряти оплату через CryptoPay API (у продакшені)
  const gift = pickGift();
  res.json({ gift });
});

app.use(express.static('.'));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));